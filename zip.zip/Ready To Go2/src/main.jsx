import React from "react";
import ReactDOM from "react-dom/client";

import { BrowserRouter, Routes, Route, Link } from "react-router-dom";

import Header from "./components/Header";
import Characters from "./components/Characters";
import Locations from "./components/Locations";
import Footer from "./components/Footer";
import Episodes from "./components/Episodes";

function Navigation() {
  return (
    <div>
      <nav>
        <ul>
          <li>
            <Link to="/a1">Przejdź do A1</Link>
          </li>
          <li>
            <Link to="/a2">Przejdź do A2</Link>
          </li>

          <li>
            <Link to="/a3">Przejdź do A3</Link>
          </li>
        </ul>
      </nav>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Header />
    <BrowserRouter>
      <Navigation />
      <Routes>
        <Route path="/a1" element={<Characters />} />
        <Route path="/a2" element={<Locations />} />
        <Route path="/a3" element={<Episodes />} />
      </Routes>
    </BrowserRouter>
    <Footer />
  </React.StrictMode>
);
