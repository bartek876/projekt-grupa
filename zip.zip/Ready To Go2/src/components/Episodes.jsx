import React, { useState, useEffect } from "react";
import Episode from "./Episode";

function Episodes() {
  function addEpisodes({ id, name, episode }) {
    return <Episode key={id} id={id} name={name} episodes={episode} />;
  }

  const [episodes, setEpisodes] = useState([]);

  useEffect(() => {
    fetch("https://rickandmortyapi.com/api/episode")
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP status: ${response.status}`);
        }
        return response.json();
      })
      .then((data) => {
        setEpisodes(data.results); // Populate the episodes state
      })
      .catch((error) => {
        console.error("Error fetching episodes:", error);
      });
  }, []);

  return <div>{episodes.map((episode) => addEpisodes(episode))}</div>;
}

export default Episodes;
