import React from "react";

function Header() {
  return <div>RICK AND MORTY</div>;
}

export default Header;
